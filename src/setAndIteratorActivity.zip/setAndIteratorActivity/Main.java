package setAndIteratorActivity;


public class Main {
    public static void main(String[] args) {
        MovieCollectionSet movieCollectionSet = new MovieCollectionSet();
        movieCollectionSet.addMovies();
        movieCollectionSet.displayMovies();
    }
}