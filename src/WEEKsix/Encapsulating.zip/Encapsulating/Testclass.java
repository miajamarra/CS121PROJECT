package WEEKsix.Encapsulating;

import WEEKsix.Classactivity.students;

public class Testclass {
    public static void main(String[] args) {
        Students Students = new Students( "Mia Lacey","8077231", "computer science", 3.0);
        System.out.printf("name: %s%n", Students.name);
       System.out.printf("idNUM: %s%n", Students.idNUM);
        System.out.printf("major: %s%n", Students.major);
        System.out.printf("gpa: %s%n", Students.gpa);
    }
}
