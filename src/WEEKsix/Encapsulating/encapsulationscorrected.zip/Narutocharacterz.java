package WEEKsix.Encapsulating;

class Narutocharactersz {

    public Object narutopower;
    public Object narutohero;
    public Object narutovillian;
    public Object attackspeed;
}

    public class Narutocharacterz {
        public static Object attackspeed;
        static String narutohero= "naruto";
        static String narutovillian = "Madara";
        static String narutopower = "ninjutsu";
        double attacckspeed = 6.0;
        public Narutocharacterz(String narutohero, String narutovillian, String narutopower, double attacckspeed){
            this.narutohero= narutohero;
            this.narutovillian=narutovillian;
            this.narutopower= narutopower;
            this.attacckspeed=attacckspeed;
        }
    }


