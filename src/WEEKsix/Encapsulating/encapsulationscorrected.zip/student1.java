package WEEKsix.Encapsulating;

public class student1 {

        String name = "Mia Lacey";
        String idNUM = "8077231";
        String major = "computer science";
        double gpa = 3.0;


        public student1(String name, String idNUM, String major, double gpa) {
            this.name = name;
            this.idNUM = idNUM;

        }

        public void students1(String name, String idNUM, String major) {
            this.name = name;
            this.idNUM = idNUM;
            this.major = major;
        }

        private void students1(String name, String idNUM) {
            this.name = name;
            this.idNUM = idNUM;
            this.major = major;
            this.gpa = gpa;
        }

        private void students1(String name) {
            this.name = name;
            this.idNUM = idNUM;
            this.major = major;
            this.gpa = gpa;
        }
    }



