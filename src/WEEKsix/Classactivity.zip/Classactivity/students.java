package WEEKsix.Classactivity;

public class students {
    String name= "Mia Lacey";
    String idNUM= "8077231";
    String major= "computer science";
    double gpa= 3.0;
    public students(String name,String idNUM, String major, double gpa){
      this.name= name;
      this.idNUM=idNUM;
      this.major=major;
      this.gpa=gpa;
    }
}
