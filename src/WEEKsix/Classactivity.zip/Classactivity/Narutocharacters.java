package WEEKsix.Classactivity;

public class Narutocharacters {
    public static Object attackspeed;
    static String narutohero= "naruto";
    static String narutovillian = "Madara";
    static String narutopower = "ninjutsu";
    double attacckspeed = 6.0;
    public Narutocharacters(String narutohero, String narutovillian,String narutopower, double attacckspeed){
       this.narutohero= narutohero;
       this.narutovillian=narutovillian;
       this.narutopower= narutopower;
       this.attacckspeed=attacckspeed;
    }
}
